Note that this is a split (into train, val, test) of the mid 2019 version of MultiWOZ 2.1, which can be found at https://doi.org/10.17863/CAM.41572
For the most recent version of MultiWOZ, please see https://github.com/budzianowski/multiwoz.git

We also provide the datasets for domain adaptation experiments, where the train datasets contain dialogue without the excluded domain.
